To reproduce builds, run the following commands in this directory:

bazel clean && bazel build //com.fasterxml.woodstox_woodstox-core:build-6.3.1

bazel clean && bazel build //com.fasterxml.woodstox_woodstox-core:build-6.3.1-endor-2024-09-03

bazel clean && bazel build //com.fasterxml.woodstox_woodstox-core:build-6.3.1-endor-latest


To run the tests, run the following commands in this directory:

bazel clean && bazel test //com.fasterxml.woodstox_woodstox-core:test-6.3.1

bazel clean && bazel test //com.fasterxml.woodstox_woodstox-core:test-6.3.1-endor-2024-09-03

bazel clean && bazel test //com.fasterxml.woodstox_woodstox-core:test-6.3.1-endor-latest

