To reproduce builds, run the following commands in this directory:

bazel clean && bazel build //org.eclipse.jgit_org.eclipse.jgit:build-6.6.0.202305301015-r

bazel clean && bazel build //org.eclipse.jgit_org.eclipse.jgit:build-6.6.0.202305301015-r-endor-2024-11-25

bazel clean && bazel build //org.eclipse.jgit_org.eclipse.jgit:build-6.6.0.202305301015-r-endor-latest


To run the tests, run the following commands in this directory:

bazel clean && bazel test //org.eclipse.jgit_org.eclipse.jgit:test-6.6.0.202305301015-r

bazel clean && bazel test //org.eclipse.jgit_org.eclipse.jgit:test-6.6.0.202305301015-r-endor-2024-11-25

bazel clean && bazel test //org.eclipse.jgit_org.eclipse.jgit:test-6.6.0.202305301015-r-endor-latest

